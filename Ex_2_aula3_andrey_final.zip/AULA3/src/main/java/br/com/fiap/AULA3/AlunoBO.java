package br.com.fiap.AULA3;



public class AlunoBO {

	public boolean validarNota1(double nota) {
		return nota>=0 && nota<=10;
		
	}
	
}
