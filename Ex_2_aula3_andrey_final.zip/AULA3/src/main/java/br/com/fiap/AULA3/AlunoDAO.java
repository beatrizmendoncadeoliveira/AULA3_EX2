package br.com.fiap.AULA3;


import java.util.ArrayList;

public class AlunoDAO {
private static ArrayList<Aluno>ALUNOS=new ArrayList<Aluno>();
	
	public void adicionar(Aluno a ) {
		ALUNOS.add(a);
	}
	public Aluno procurar(String nome) {
		for(Aluno a :ALUNOS) {
			if(a.getNome().equals(nome)) {
				return a;
			}
		}return null;
	}

}
