
function getCookie(name){
	var value=";"+document.cookie;
	var parts=value.split(";"+name+"=");
	if(parts.length==2)return parts.pop().split(";").shift();
	
	
}

var nome=getCookie("nome");
var p1=parseFloat(getCookie("p1"));
var p2=parseFloat(getCookie("p2"));

var media=(p1+p2)/2;

if(media>6){
	texto="Aprovado, media maior que 6";
}else{
	texto="Media menor que 6, reprovado";
}

document.querySelector("#nome").querySelector("span").textContent=nome;
document.querySelector("#p1").querySelector("span").textContent=p1.toFixed(1);
document.querySelector("#p2").querySelector("span").textContent=p2.toFixed(1);
document.querySelector("#media").querySelector("span").textContent=media.toFixed(1);
document.querySelector("#texto").querySelector("span").textContent=texto;